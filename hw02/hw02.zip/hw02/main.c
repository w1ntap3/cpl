#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define ARG_FLOAT_COUNT 6

int raycast(double angle_deg, double distance_m, double cell_size_m,
            int ***out_cells, int *out_count);

int main(int argc, char *argv[]) {
  float arg_floats[ARG_FLOAT_COUNT]; // indexing follows the order of arguments
                                     // from courseware
  for (int i = 0; i < ARG_FLOAT_COUNT; i++) {
    arg_floats[i] = strtof(argv[i + 1], NULL);
  }

  for (int i = 0; i < ARG_FLOAT_COUNT; i++) {
    printf("arg_floats[%d]: %f\n", i, arg_floats[i]);
  }

  printf("javaaa\n");
  return 0;
}

int raycast(double angle_deg, double distance_m, double cell_size_m,
            int ***out_cells, int *out_count) {
  if (!out_cells || !out_count || distance_m < cell_size_m) {
    return 0;
  }

  double angle_rad = angle_deg * 3.14159265358979323846 / 180.0;
  double end_x = distance_m * cos(angle_rad);
  double end_y = distance_m * sin(angle_rad);
  int x0 = 0, y0 = 0;
  int x1 = (int)(end_x / cell_size_m);
  int y1 = (int)(end_y / cell_size_m);
  int dx = abs(x1 - x0);
  int dy = abs(y1 - y0);
  int sx = (x0 < x1) ? 1 : -1;
  int sy = (y0 < y1) ? 1 : -1;
  int err = dx - dy;

  int max_cells = dx + dy + 1;
  int **cells = malloc(max_cells * sizeof(int *));
  if (!cells) {
    return 0;
  }

  int count = 0;

  while (1) {
    cells[count] = malloc(2 * sizeof(int));
    if (!cells[count]) {
      // Clean up previously allocated memory
      for (int i = 0; i < count; i++) {
        free(cells[i]);
        cells[i] = NULL;
      }
      free(cells);
      cells = NULL;
      return 0;
    }
    cells[count][0] = x0;
    cells[count][1] = y0;
    count++;

    if (x0 == x1 && y0 == y1) {
      break;
    }

    int e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x0 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y0 += sy;
    }
  }

  *out_cells = cells;
  *out_count = count;
  return 1;
}
