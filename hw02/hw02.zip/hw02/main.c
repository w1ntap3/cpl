#include <stdio.h>

int main(int argc, char *argv[]) {
  printf("javaaa\n");
  return 0;
}
